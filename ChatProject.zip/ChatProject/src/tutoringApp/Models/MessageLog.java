package tutoringApp.Models;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class MessageLog implements Serializable {
    private static final long serialVersionUID = 1L;

    private String content;

    public MessageLog(String content) {
        this.content = content;
    }

    public MessageLog() {}

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    private void writeObject(ObjectOutputStream out) throws IOException {
        System.out.println("Serializing content: " + content);
        byte[] contentBytes = content.getBytes("UTF-8");
        out.writeInt(contentBytes.length);
        out.write(contentBytes);
    }

    private void readObject(ObjectInputStream in) throws IOException, ClassNotFoundException {
        int contentLength = in.readInt();
        byte[] contentBytes = new byte[contentLength];
        in.readFully(contentBytes);
        content = new String(contentBytes, "UTF-8");
        System.out.println("Deserializing content: " + content);
    }

    @Override
    public String toString() {
        return content;
    }
}