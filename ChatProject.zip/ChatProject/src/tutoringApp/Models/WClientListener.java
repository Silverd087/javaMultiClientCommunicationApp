package tutoringApp.Models;

public interface WClientListener {
	void onMessageRecieved(String message);

}
